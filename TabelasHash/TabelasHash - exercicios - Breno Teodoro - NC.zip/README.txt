ol� professor!
Desculpas pelo material digital do exerc�cio, tive alguns problemas 
com a scanner e n�o consegui scannear na UEPG pois a manarim j� estava fechada.